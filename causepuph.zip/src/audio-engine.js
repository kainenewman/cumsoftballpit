; // jshint ignore:line
(function (root, factory, undefined) {
  'use strict';
  if (typeof define === 'function' && define.amd) {
    define([], factory);
  } else if (typeof exports === 'object') {
    module.exports = factory();
  } else {
    // root is window
    root.AudioEngine = factory();
  }
}(window, function () {
  'use strict';

  var AudioEngine,
    document = window.document;

  AudioEngine = function () 
  {
    if (!(this instanceof AudioEngine)) {
      return new AudioEngine();
    }

    this.context = new AudioContext();

    this.gainNode = this.context.createGain();

    this.gainNode.gain.value = 1;
    
    this.gainNode.connect(this.context.destination);

    this.MusicMap = {};

    this.init();
  };

  AudioEngine.prototype = {
    init: function () 
    {

      var _this = this; 
    },

    load: function(URL, TAG, looped, onLoaded)
    {
      var _this = this; 

      _this.MusicMap[TAG] = { 
          MenuSource : undefined,
          MenuAudioBuffer : undefined,
          URL : URL,
          Loop : looped
        };

      window.fetch(URL)
      .then(response => response.arrayBuffer())
      .then(arrayBuffer => _this.context.decodeAudioData(arrayBuffer))
      .then(audioBuffer => {
        _this.MusicMap[TAG].MenuAudioBuffer = audioBuffer;

        if(onLoaded != undefined)
        {
          onLoaded(URL);
        }
      });  
    },

    setVolume : function(value)
    {
        var _this = this;

        _this.gainNode.gain.value = value;
    },

    play: function (TAG) 
    {
      var _this = this;

      if(_this.MusicMap[TAG] != undefined)
      {
        _this.MusicMap[TAG].MenuSource = _this.context.createBufferSource();
        _this.MusicMap[TAG].MenuSource.buffer = _this.MusicMap[TAG].MenuAudioBuffer;
        _this.MusicMap[TAG].MenuSource.connect(_this.gainNode);
        _this.MusicMap[TAG].MenuSource.loop = _this.MusicMap[TAG].Loop;
        _this.MusicMap[TAG].MenuSource.start();
      }
    },

    stop: function (TAG) 
    {
         var _this = this;

          if(_this.MusicMap[TAG] != undefined)
          {
            if(_this.MusicMap[TAG].MenuSource != undefined)
            {
              _this.MusicMap[TAG].MenuSource.stop();
              _this.MusicMap[TAG].MenuSource = undefined;              
            }
          }         
    },
  };

  return AudioEngine;
}));
