; // jshint ignore:line
(function (root, factory, undefined) {
  'use strict';
  if (typeof define === 'function' && define.amd) {
    define([], factory);
  } else if (typeof exports === 'object') {
    module.exports = factory();
  } else {
    // root is window
    root.AgeGate = factory();
  }
}(window, function () {
  'use strict';

  var AgeGate,
    document = window.document;

  AgeGate = function (okFunction, nokFunction, showOnStart) 
  {
    if (!(this instanceof AgeGate)) 
    {
      return new AgeGate(okFunction, nokFunction, true);
    }    

    this.AgeSelected = 0;
    this.okFunction = okFunction;
    this.nokFunction = nokFunction;
    this.showOnStart = showOnStart;

    this.init();
  };

  AgeGate.prototype = {
    init: function () 
    {
      var _this = this;

      if(this.showOnStart)
      {
        this.showBanner();   
      }
    },

    /*
     * Show banner at the top of the page
     */
    showBanner: function () {
      var _this = this,
        getElementById = document.getElementById.bind(document),
        banner = getElementById('age-gate-table'),
        age08 = getElementById('age-button-08'),
        age912 = getElementById('age-button-912'),
        age1317 = getElementById('age-button-1317'),
        age1824 = getElementById('age-button-1824'),
        age25 = getElementById('age-button-25'),
        close = getElementById('age-button-close'),
        addClickListener = this.addClickListener;

      banner.style.display = 'block';
      banner.classList.add('age-gate-show');
      
      if(age08)
      {
        addClickListener(age08, function () 
        {
          _this.removeBanner();

          _this.nokFunction();          
          _this.AgeSelected = 1;          

          var noPage = document.getElementById('age-gate-error');
          noPage.style.display = 'block';
          noPage.classList.add('age-gate-show');           
          
        });
      }

      if(age912)
      {
        addClickListener(age912, function () 
        {
          _this.removeBanner();

          _this.nokFunction();

          _this.AgeSelected = 2;

          var noPage = document.getElementById('age-gate-error');
          noPage.style.display = 'block';
          noPage.classList.add('age-gate-show');          
          
        });   
      }

      if(age1317)
      {
        addClickListener(age1317, function () 
        {
          _this.removeBanner();

          _this.AgeSelected = 3;        

          _this.okFunction();
          
        });   
      }

      if(age1824)
      {
        addClickListener(age1824, function () 
        {
          _this.removeBanner();

          _this.AgeSelected = 4;        

          _this.okFunction();
          
        });              
      }

      if(age25)
      {
        addClickListener(age25, function () 
        {
          _this.removeBanner();

          _this.AgeSelected = 5;        

          _this.okFunction();
          
        });                    
      }

      if(close)
      {
        addClickListener(close, function () 
        {
           _this.removeEnd();

          
        });                    
      }      
      
    },

    addClickListener: function (DOMElement, callback) {
      if (DOMElement.attachEvent) { // For IE 8 and earlier versions
        return DOMElement.attachEvent('onclick', callback);
      }

      // For all major browsers, except IE 8 and earlier
      DOMElement.addEventListener('click', callback);
    },

    /*
     * Delays removal of banner allowing developers
     * to specify their own transition effects
     */
    removeBanner: function (wait) {
      var banner = document.getElementById('age-gate-table');
      banner.classList.add('age-gate-before-remove');

      setTimeout (function() {
        if (banner && banner.parentNode) {
          banner.parentNode.removeChild(banner);
        }
      }, wait);
    },

    /*
     * Delays removal of banner allowing developers
     * to specify their own transition effects
     */
    removeEnd: function (wait) {
      var banner = document.getElementById('age-gate-error');
      banner.classList.add('age-gate-before-remove');

      setTimeout (function() {
        if (banner && banner.parentNode) {
          banner.parentNode.removeChild(banner);
        }
      }, wait);
    }
  };

  return AgeGate;
}));
