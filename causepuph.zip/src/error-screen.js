; // jshint ignore:line
(function (root, factory, undefined) {
  'use strict';
  if (typeof define === 'function' && define.amd) {
    define([], factory);
  } else if (typeof exports === 'object') {
    module.exports = factory();
  } else {
    // root is window
    root.ErrorScreen = factory();
  }
}(window, function () {
  'use strict';

  var ErrorScreen,
    document = window.document;

  ErrorScreen = function (title, message) 
  {
    if (!(this instanceof ErrorScreen)) {
      return new ErrorScreen("ERROR", "Ohh no!");
    }

    this.title = title;
    this.message = message;

    this.init();
  };

  ErrorScreen.prototype = {
    init: function () 
    {

      var _this = this;

      setTimeout (function() 
      {
        _this.showBanner();   
      }, this.intialTimeout);      
    },

    /*
     * Show banner at the top of the page
     */
    showBanner: function () {
      var _this = this,
        getElementById = document.getElementById.bind(document),
        banner = getElementById('error-screen-error'),
        closeButton = getElementById('error-screen-close'),
        title =  getElementById('error-screen-title'),
        message =  getElementById('error-screen-message'),
        addClickListener = this.addClickListener;

      banner.style.display = 'block';
      banner.classList.remove('error-screen-before-remove');
      banner.classList.add('error-screen-show');       

      message.innerHTML = _this.message;
      title.innerHTML = _this.title;   

       if (closeButton) {
        addClickListener(closeButton, function () 
        {
          _this.removeBanner();
        });
      }

    },

    addClickListener: function (DOMElement, callback) {
      if (DOMElement.attachEvent) { // For IE 8 and earlier versions
        return DOMElement.attachEvent('onclick', callback);
      }

      // For all major browsers, except IE 8 and earlier
      DOMElement.addEventListener('click', callback);
    },

    /*
     * Delays removal of banner allowing developers
     * to specify their own transition effects
     */
    removeBanner: function (wait) {
      var banner = document.getElementById('error-screen-error');
      
      banner.classList.remove('error-screen-show');
      banner.classList.add('error-screen-before-remove');

      setTimeout (function() {
        if (banner && banner.parentNode) {
          //banner.parentNode.removeChild(banner);
          banner.style.display = 'none';
        }
      }, wait);
    }
  };

  return ErrorScreen;
}));
