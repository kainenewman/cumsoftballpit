; // jshint ignore:line
(function (root, factory, undefined) {
  'use strict';
  if (typeof define === 'function' && define.amd) {
    define([], factory);
  } else if (typeof exports === 'object') {
    module.exports = factory();
  } else {
    // root is window
    root.Permissions = factory();
  }
}(window, function () {
  'use strict';

  var Permissions,
    document = window.document;

    Permissions = function (initialTime, interval, url, allowFunction, skipFunction) 
  {
    if (!(this instanceof Permissions)) {
      return new Permissions(5000,15000,"http://www.acuteart.com", function() 
      {

      });
    }

    this.intialTimeout = initialTime; // 5 seconds
    this.showTimeout = interval; // 15 seconds    
    this.url = url;
    this.allowFunction = allowFunction;
    this.skipFunction = skipFunction;

    this.init();
  };

  Permissions.prototype = {
    init: function () 
    {

      var _this = this;

      if(this.intialTimeout >= 0)
      {
        setTimeout (function() 
        {
          _this.showBanner();   
        }, this.intialTimeout);      
      }
    },

    /*
     * Show banner 
     */
    showBanner: function () {
      var _this = this,
        getElementById = document.getElementById.bind(document),
        banner = getElementById('permissions'),
        allowButton = getElementById('permissions-allow'),
        skipButton = getElementById('permissions-skip'),
        addClickListener = this.addClickListener;

      banner.style.display = 'block';
      banner.classList.remove('permissions-before-remove');
      banner.classList.add('permissions-show');      
      

      if (allowButton) {
        addClickListener(allowButton, function () 
        {
          _this.removeBanner();

          console.log("PermissionRequestCamera");
          var zappar = ZCV.initialize();
          //console.log(zappar);
          if (!zappar.permission_granted_all()) {
            zappar.permission_request_all();
          }

          if(_this.allowFunction != undefined)
            _this.allowFunction();
          
        });
      }

      
      if (skipButton) {
        addClickListener(skipButton, function () 
        {
          _this.removeBanner();

          if(_this.skipFunction != undefined)
            _this.skipFunction();
        });
      }


      if(this.showTimeout > 0)
      {
        setTimeout (function() 
        {
          try
          {
            if(_this)
            {
              _this.removeBanner();   
            }
          }
          catch (err)
          {

          }
        }, this.showTimeout);     
      }
    },
    addClickListener: function (DOMElement, callback) {
      if (DOMElement.attachEvent) { // For IE 8 and earlier versions
        return DOMElement.attachEvent('onclick', callback);
      }

      // For all major browsers, except IE 8 and earlier
      DOMElement.addEventListener('click', callback);
    },

    /*
     * Delays removal of banner allowing developers
     * to specify their own transition effects
     */
    removeBanner: function (wait) {
      var banner = document.getElementById('permissions');
      
      banner.classList.remove('permissions-show');
      banner.classList.add('permissions-before-remove');

      setTimeout (function() {
        if (banner && banner.parentNode) {
          //banner.parentNode.removeChild(banner);
          banner.style.display = 'none';
        }
      }, wait);
    }
  };

  return Permissions;
}));
