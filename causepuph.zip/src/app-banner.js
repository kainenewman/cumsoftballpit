; // jshint ignore:line
(function (root, factory, undefined) {
  'use strict';
  if (typeof define === 'function' && define.amd) {
    define([], factory);
  } else if (typeof exports === 'object') {
    module.exports = factory();
  } else {
    // root is window
    root.AppBanner = factory();
  }
}(window, function () {
  'use strict';

  var AppBanner,
    document = window.document;

  AppBanner = function (initialTime, interval, url) 
  {
    if (!(this instanceof AppBanner)) 
    {
        return new AppBanner(5000,15000,url);
    }

    this.intialTimeout = initialTime; // 5 seconds
    this.showTimeout = interval; // 15 seconds    
    this.url = url;

    this.init();
  };

  AppBanner.prototype = {
    init: function () 
    {

      var _this = this;

      setTimeout (function() 
      {
        _this.showBanner();   
      }, this.intialTimeout);      
    },

    /*
     * Show banner at the top of the page
     */
    showBanner: function () {
      var _this = this,
        getElementById = document.getElementById.bind(document),
        banner = getElementById('app-banner'),
        clickButton = getElementById('app-banner-click'),
        closeButton = getElementById('app-banner-close'),
        addClickListener = this.addClickListener;

      banner.style.display = 'block';
      banner.classList.remove('app-banner-before-remove');
      banner.classList.add('app-banner-show');      
      

      if (clickButton) {
        addClickListener(clickButton, function () 
        {
          _this.removeBanner();
          
          var win = window.open(_this.url, '_blank');
          win.focus();
          
        });
      }

       if (closeButton) {
        addClickListener(closeButton, function () 
        {
          _this.removeBanner();
        });
      }

      setTimeout (function() 
      {
        try
        {
          if(_this)
          {
            _this.removeBanner();   
          }
        }
        catch (err)
        {

        }
      }, this.showTimeout);     
    },

    addClickListener: function (DOMElement, callback) {
      if (DOMElement.attachEvent) { // For IE 8 and earlier versions
        return DOMElement.attachEvent('onclick', callback);
      }

      // For all major browsers, except IE 8 and earlier
      DOMElement.addEventListener('click', callback);
    },

    /*
     * Delays removal of banner allowing developers
     * to specify their own transition effects
     */
    removeBanner: function (wait) {
      var banner = document.getElementById('app-banner');
      
      banner.classList.remove('app-banner-show');
      banner.classList.add('app-banner-before-remove');

      setTimeout (function() {
        if (banner && banner.parentNode) {
          //banner.parentNode.removeChild(banner);
          banner.style.display = 'none';
        }
      }, wait);
    }
  };

  return AppBanner;
}));
