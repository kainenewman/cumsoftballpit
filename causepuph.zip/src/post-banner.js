; // jshint ignore:line
(function (root, factory, undefined) {
  'use strict';
  if (typeof define === 'function' && define.amd) {
    define([], factory);
  } else if (typeof exports === 'object') {
    module.exports = factory();
  } else {
    // root is window
    root.PostBanner = factory();
  }
}(window, function () {
  'use strict';

  var PostBanner,
    document = window.document;

  PostBanner = function (initialTime, interval, url, closeFunction) 
  {
    if (!(this instanceof PostBanner)) {
      return new PostBanner(5000,15000,url, function() 
      {

      });
    }

    this.intialTimeout = initialTime; // 5 seconds
    this.showTimeout = interval; // 15 seconds    
    this.url = url;
    this.closeFunction = closeFunction;

    this.init();
  };

  PostBanner.prototype = {
    init: function () 
    {

      var _this = this;

      if(this.intialTimeout >= 0)
      {
        setTimeout (function() 
        {
          _this.showBanner();   
        }, this.intialTimeout);      
      }
    },

    /*
     * Show banner 
     */
    showBanner: function () {
      var _this = this,
        getElementById = document.getElementById.bind(document),
        banner = getElementById('post-game'),
        clickButton = getElementById('post-game-download'),
        closeButton = getElementById('post-game-close'),
        addClickListener = this.addClickListener;

      banner.style.display = 'block';
      banner.classList.remove('post-game-before-remove');
      banner.classList.add('post-game-show');      
      

      if (clickButton) {
        addClickListener(clickButton, function () 
        {
          _this.removeBanner();

          if(_this.closeFunction != undefined)
            _this.closeFunction();
          
          var win = window.open(_this.url, '_blank');
          win.focus();
          
        });
      }

      if (closeButton) {
        addClickListener(closeButton, function () 
        {
          _this.removeBanner();

          if(_this.closeFunction != undefined)
            _this.closeFunction();
        });
      }

      if(this.showTimeout > 0)
      {
        setTimeout (function() 
        {
          try
          {
            if(_this)
            {
              _this.removeBanner();   
            }
          }
          catch (err)
          {

          }
        }, this.showTimeout);     
      }
    },

    addClickListener: function (DOMElement, callback) {
      if (DOMElement.attachEvent) { // For IE 8 and earlier versions
        return DOMElement.attachEvent('onclick', callback);
      }

      // For all major browsers, except IE 8 and earlier
      DOMElement.addEventListener('click', callback);
    },

    /*
     * Delays removal of banner allowing developers
     * to specify their own transition effects
     */
    removeBanner: function (wait) {
      var banner = document.getElementById('post-game');
      
      banner.classList.remove('post-game-show');
      banner.classList.add('post-game-before-remove');

      setTimeout (function() {
        if (banner && banner.parentNode) {
          //banner.parentNode.removeChild(banner);
          banner.style.display = 'none';
        }
      }, wait);
    }
  };

  return PostBanner;
}));
